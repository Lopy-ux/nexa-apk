NEXA APK (dasar proyek Android)
================================
Ini aplikasi pembungkus (WebView) untuk NEXA. Isinya: mic untuk voice note dan
telepon, kamera untuk video call, pilih file/foto/video, unduh file, tombol back
yang benar, halaman "Tidak bisa terhubung" kalau server mati, dan layar penuh video.

CARA BUAT APK DARI HP (tanpa laptop, gratis)
1. Buat akun di github.com, lalu buat repository baru (boleh Private).
2. Unggah SEMUA isi folder ini ke repository, termasuk folder ".github".
   Kalau lewat browser HP susah mengunggah folder, pakai "Add file > Upload files"
   dari zip yang sudah diekstrak, atau gunakan aplikasi seperti Termux/Git.
3. Buka tab "Actions". Workflow "Build APK" jalan otomatis (atau tekan "Run workflow").
4. Tunggu sekitar 3-6 menit sampai centang hijau, buka run-nya, turun ke bagian
   "Artifacts", unduh "NEXA-apk" (zip berisi NEXA.apk), ekstrak, lalu pasang.

MENGGANTI ALAMAT / NAMA
Edit file config.properties (APP_URL, APP_NAME), simpan (commit), dan Actions akan
membuat APK baru. Itu satu-satunya file yang perlu diubah.

CATATAN
- Telepon/voice note butuh HTTPS supaya stabil. Pakai alamat https:// di APP_URL.
- Alamat http:// tetap bisa dibuka (cleartext diizinkan), tapi mic di WebView
  umumnya hanya jalan di HTTPS atau localhost.
- Notifikasi push saat aplikasi ditutup belum ada (WebView tidak mendukung Web
  Notification). Itu butuh Firebase dan kode tambahan.
- APK ini ditandatangani kunci debug: bisa dipasang langsung, tapi bukan untuk Play Store.
- Jika memakai Android Studio: Open folder ini, lalu Build > Build APK.
